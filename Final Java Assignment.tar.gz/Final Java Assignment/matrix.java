import java.util.Scanner;
class matrix
{
        int a[][],b[][],c[][],d[][],k[][],m,n;
        matrix(int m,int n)
        {
            this.m=m;
            this.n=n;
            a=new int[m][n];
            b=new int[m][n];
            c=new int[m][n];
            k=new int[m][n];
            d=new int[m][n];

        }
        public void getdata()
        {
            Scanner sc=new Scanner(System.in);
        
            System.out.println("Enter the elements of first matrix");
      for(int i=0;i<this.m;i++)
      {
          for(int j=0;j<this.n;j++)
          {
              a[i][j]=sc.nextInt();
          }
      }
      System.out.println("Enter the elements of second matrix");
      for(int i=0;i<this.m;i++)
      { 
          
          for(int j=0;j<this.n;j++)
          {
                b[i][j]=sc.nextInt();
          }
      }
     
    }
        public void addition()
        {   
          
          for(int i=0;i<this.m;i++)
          {
              for(int j=0;j<this.n;j++)
              {
                  c[i][j]=a[i][j]+b[i][j];
              }
          }
          System.out.println("The matrix addition is");
          for(int i=0;i<this.m;i++)
          {
              for(int j=0;j<this.n;j++)
              {
            

                 System.out.print(c[i][j]);
                 System.out.print(" ");
              }
              System.out.println(" ");
          }


            
        }
        public void multiplication()
        {
            if(this.m==this.n)
            {
                System.out.println("Multiplying the matrices...");
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        for (int k = 0; k < n; k++)
                        {
                            d[i][j] = d[i][j] + a[i][k] * b[k][j];
                        }
                    }
                }
                System.out.println("The product is:");
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        System.out.print(d[i][j] + " ");
                    }
                    System.out.println();
                }
            }
            else{
                System.out.println("The matrix is not a squared matrix");
            }
        }
    public static void main(String[] args) {
      matrix m=new matrix(2,2);
        m.getdata();
        m.addition();
        m.multiplication();
        

    }
}