
//1.Overload a constructor of class cone.Create at least two instances of cone demonstrate constructor overloading.The class has two methods,which return area and volume.Implemnet "this" keyword in Java.

import java.lang.Math;
class base
{
    private float r,h;
    base()
    {
        r=5;
        h=5;
    }
    base(float r,float h)
    {
        this.r=r;
        this.h=h;
    }
    void volume()
    {
        double vol;
        vol=(3.14*r*r*h)/3;
        System.out.println("The volume of cone is"+vol);
    } 
    void area()
    {
        double ar;
        ar=3.148*r*(r+Math.sqrt(h*h+r*r));
        System.out.println("The area of cone is"+ar);

    }
}
class cone
{
    public static void main(String args[])
    {
        base c1=new base();
        base c2=new base(10,10);
        c1.area();
        c1.volume();
        c2.area();
        c2.volume();
    }
}
