import java.util.Scanner;
class account
{
    protected String custName;
    protected int accNumber;
    private String typeOfAccount;
    account()
    {
        this.custName="NULL";
        this.accNumber=0000;
        this.typeOfAccount="NULL";
       
    }
    account(String cname,int anumber)
    {
        this.custName=cname;
        this.accNumber=anumber;
        
       
    }    

}

class savingsAccount extends account{
    private int totalBalance;
   private int amount;
    int mimBalance=1000;

    savingsAccount(account acc,int depositFirstAmmount)
    {
            this.custName=acc.custName;
            this.accNumber=acc.accNumber;
            this.totalBalance=depositFirstAmmount;
            
    }
void deposit()
{   
    System.out.println("Enter the ammount you want to deposit");
    Scanner sc=new Scanner(System.in);
    amount=sc.nextInt();
    totalBalance=totalBalance+amount;

}
        void checkMimBalance()
        {
            if(totalBalance<mimBalance)
            {
                totalBalance=totalBalance-50;
            }
        }
void withdrawl()
{   
    System.out.println("Enter the ammount you want to withdraw");
    Scanner sc=new Scanner(System.in);
    amount=sc.nextInt();
    if(amount>totalBalance){
        System.out.println("You donot have that much amount to withdraw");
    }
    else{
    totalBalance=totalBalance-amount;
    }

}
void showBalance(){
    checkMimBalance();
    System.out.println("The total balance in your account is: "+totalBalance);

}

}
class currentAccount extends account
{       
    private int totalBalance;
   private int amount;

    protected int currentTotalBalance;

    currentAccount(account acc)
    {
            this.custName=acc.custName;
            this.accNumber=acc.accNumber;
    }
    void deposit()
    {

    System.out.println("Enter the ammount you want to deposit");
    Scanner sc=new Scanner(System.in);
    amount=sc.nextInt();
    totalBalance=totalBalance+amount;
    }
    void withdrawl()
    {
          
    System.out.println("Enter the ammount you want to withdraw");
    Scanner sc=new Scanner(System.in);
    amount=sc.nextInt();
    if(amount>totalBalance){
        System.out.println("You donot have that much amount to withdraw");
    }
    else{
    totalBalance=totalBalance-amount;
    
    }
}
    void showBalance(){
        System.out.println("The total balance in your account is: "+totalBalance);

    }
}


public class bank {
        public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);

            account acc=new account("Ranson",742123);
            savingsAccount sa=new savingsAccount(acc,2500);
            currentAccount ca=new currentAccount(acc);
            System.out.println("**** Welecome to banking ****");
            int toa,flag=1;
            while(flag!=0)
            {
           
            System.out.println("Enter type of account you want to perform operations 1.Savings Account 2.Current Account 3.Exit");
            toa=sc.nextInt();
          
            switch(toa)
            {

                 case 1:{
                    int ch=0;
                    boolean valid=true;

                    while(valid!=false)
                    {
                    System.out.println("Enter the operation you want to perform "+" 1.Deposit 2.Withdrwal 3.Display Balance 4.Back");
                    
                    ch=sc.nextInt();
                   
                            switch(ch)
                            {
                                case 1: sa.deposit();
                                    break;
                                case 2:sa.withdrawl();
                                break;
                                case 3:sa.showBalance();
                                break;
                                case 4: valid=false;
                                    break;
                                default: System.out.println("Please enter a valid choice");
                            }
                    }
                    break; 
                 }  
                 case 2: {
                    int ch;
                        int valid=1;
                    while(valid!=0)
                    {
                    System.out.println("Enter the operation you want to perform "+" 1.Deposit 2.Withdrwal 3.Display Balance 4.Back");
                    
                    ch=sc.nextInt();
                   
                            switch(ch)
                            {
                                case 1: ca.deposit();
                                    break;
                                case 2:ca.withdrawl();
                                break;
                                case 3:ca.showBalance();
                                break;
                                case 4:valid=0;
                                break;
                                default: System.out.println("Please enter a valid choice");
                            }
                    }
                  break; 
                 }
                 case 3:flag=0;
                 break;
                 default:System.out.println("You have entered a wrong choice");

           
           
              
        }
    }
}
}

       

