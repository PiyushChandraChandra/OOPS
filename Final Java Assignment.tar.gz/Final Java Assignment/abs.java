import java.lang.Math;
import java.util.Scanner;
abstract class shape
{
    
    abstract public double area();
    abstract public double volume();
    abstract public void getdata();

}
class cube extends shape
{
    
    int a;
   
    
   public void getdata()
    {
        Scanner sc=new Scanner(System.in);
        float ar;
        System.out.println("Enter side of cube:");
        ar=sc.nextInt();
       

    }
    public double volume()
    {
        float vol;
        Scanner sc=new Scanner(System.in);
       
        vol=a*a*a;
        System.out.println("The volume of cube is:"+vol);
        return vol;

    }
    public double area()
    {
        float ar;
       ar=6*a*a;
       System.out.println("The area of cube is"+ar);
       return ar;
    }
}
class cone extends shape
{
    Scanner sc=new Scanner(System.in);
    int r,h;
    double vol;
    double ar;
   public void getdata()
    {
        System.out.println("Enter radius and height:");
        r=sc.nextInt();
        h=sc.nextInt();
       
    }
    public  double volume()
    {
       

        vol=(3.14*r*r*h)/3;
        System.out.println("The volume of cone is:"+vol);
        return vol;
    }
    public double area()
    {
        ar=3.14*r*(r+Math.sqrt(r*r+h*h));
        System.out.println("The area of cone is:"+ar);
        return ar;

    }
}
class abs
{
    public static void main(String args[])
    {
      shape s[]=new shape[2];
     
      s[0]=new cone();
      s[1]=new cube();
      s[0].getdata();
      s[1].getdata();

      s[0].volume();

      s[1].volume();
      s[0].area();
      s[1].area();

    


        

    }
}
