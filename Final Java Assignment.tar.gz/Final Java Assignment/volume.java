//4.Define a class voulme and then find out the volume of cube, cylindera and rectangular box using method overloading.

class shape
{
    private float l,b,h,r;
    float volume()
    {
        float vol;
        l=10;
        vol=l*l*l;
        return vol;
    }
    float volume(float l,float b,float h)
    {
        float vol;
        vol=l*b*h;
        return vol;
    }
double volume(float r,float h)
    {
        double vol;
        vol=3.14*r*r*h;
        return vol;
    }
}
class volume
{
    public static void main(String args[])
    {
        shape s=new shape();
        System.out.println("The volume of cube is"+s.volume());
        System.out.println("The volume of cuboid is"+s.volume(10,20,30));
        System.out.println("The volume of cylinder is"+s.volume(20,30));
    }
}
