class base
{
    int top;
    int[] arr=new int[5];
    base()
    {
        top=-1;
        
    }
    void push(int val)
    {   if(top==4)
        {
            System.out.println("The stack is full");
        }
        else
        {
        top=top+1;
        arr[top]=val;

        }
        

    }
    void pop()
    {
    int temp;
      if(top==-1)
        {
            System.out.println("The stack is empty");
        }
        else
        {
       
        temp=arr[top];
        top--;
        }
        
    
}
    void display()
    {
        int i;
        for(i=top;i>-1;i--)
        {
            System.out.println(arr[i]);
        }
    }
}
class stack
{
    public static void main(String args[])
    {
        base s1=new base();
    
    s1.push(5);
    s1.push(10);
    s1.push(50);
    s1.push(40);
    s1.pop();
    s1.display();
    }
}