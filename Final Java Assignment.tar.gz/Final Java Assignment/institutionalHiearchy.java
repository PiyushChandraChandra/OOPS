import java.util.Scanner;
class staff
{
   public String name;
    public int code;
}
   
class officer extends staff
{
    String grade;
}
class teacher extends staff{
    String subject;
}
class typist extends staff
{
    int speed;
}
class casualTypist extends typist
{
    int dwage;
}
class regularTypist extends typist
{
    int renumeration;
}
class institutionalHiearchy
{
    public static void main(String args[])
     {
         officer o[]=new officer[1];
         o[0]=new officer();
         o[0].name="SRk";
         o[0].code=1;
         o[0].grade="A";

         teacher t[]=new teacher[1];
         t[0]=new teacher();
         t[0].code=2;
         t[0].subject="Physics";
         t[0].name="Ayush";

         casualTypist ct[]=new casualTypist[1];
         ct[0]=new casualTypist();
         ct[0].code=3;
         ct[0].dwage=200;
         ct[0].name="Anup";
         ct[0].speed=5;

         regularTypist rt[]=new regularTypist[1];
         rt[0]=new regularTypist();
         rt[0].renumeration=250;
         rt[0].code=4;
         rt[0].name="Suresh";
         rt[0].speed=4;
    



        
        

    }
}
