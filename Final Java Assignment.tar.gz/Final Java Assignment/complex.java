//2.Create a class Complex class to implement complex addition,substraction,multiplication and division, finding argument of the complex number.Use construtor overloading.

class complex1
{
    private float real,imag;
    complex1()
    {
        real=400;
        imag=40;
    }
    complex1(int a,int b)
    {
        real=a;
        imag=b;
    }
  public  void  sum(complex1 x,complex1 y)
    {
        
        this.real=x.real+y.real;
        this.imag=x.imag+y.imag;
        System.out.println("The addition is"+this.real+"+"+this.imag+"i");
        

    }
   public void subtract(complex1 x,complex1 y)
    {
        
        this.real=x.real-y.real;
        this.imag=x.imag-y.imag;
        System.out.println("The subtraction is"+this.real+"-"+this.imag+"i");
        

    }
    public void multiply(complex1 x,complex1 y)
    {
        
        this.real=x.real*y.real;
        this.imag=x.imag*y.imag;
        System.out.println("The multiplication is"+this.real+"*"+this.imag+"i");
        

    }
    public void divide(complex1 x,complex1 y)
    {
       
        this.real=x.real/y.real;
        this.imag=x.imag/y.imag;
        System.out.println("The division is is"+this.real+"/"+this.imag+"i");
        

    }
}
class complex
{
    public static void main(String args[])
    {
        complex1 c1=new complex1();
        complex1 c2=new complex1(200,20);
        complex1 c3=new complex1();
        c3.sum(c1,c2);
        c3.subtract(c1,c2);
        c3.multiply(c1,c2);
        c3.divide(c1,c2);
    }
}
